based on recovered skeleton
